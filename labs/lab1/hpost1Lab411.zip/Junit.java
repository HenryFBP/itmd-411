package lab1;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class Junit {

	
	private AccountHolder account;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception
	{
	}

	@Before
	public void setUp() throws Exception
	{
		account = new AccountHolder(0);
	}

	@Test
	public void testInitialInterest()
	{
		if(account.annualInterestRate != 0)
		{
			fail("Account initial interest is not zero. It is '" + account.annualInterestRate + "'");
		}
	}
	
	@Test
	public void testBalance()
	{
		account = new AccountHolder(-269863945);
		if(account.balance < 0)
		{
			fail("Account balance is less than zero.");
		}
	}
	
	@Test
	public void testModifyInterest()
	{
		double rate = 0.05;
		double bal = 1000;
		account = new AccountHolder(bal);
		account.modifyMonthlyInterest(rate);
		
		for(int i = 0; i < 999; i++)
		{
			bal = bal + (bal * (rate / 12.0)); //compound interest
			account.monthlyInterest(account.balance);
			
			if(account.balance != bal)
			{
				fail("Acc.bal != bal aka '" + account.balance + "' != '" + bal + "'");
			}
		}
		
	}
	
	@Test
	public void testNullObject()
	{
		account = null;
		if(account != null)
		{
			fail("Assigning null value to account somehow failed!");
		}
	}
	
	protected void tearDown() throws Exception
	{
		System.out.println("Running teardown.");
		account = null;
		assertNull(account);
	}
	

}
