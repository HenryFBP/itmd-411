

public abstract class Client
{

    public abstract void readData();  //read file detail
    public abstract void processData();  
    public abstract void printData();  
}
